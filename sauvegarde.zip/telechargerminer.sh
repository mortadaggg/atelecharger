#!/bin/bash
SCRIPT="wget https://github.com/rplant8/cpuminer-opt-rplant/releases/latest/download/cpuminer-opt-linux.tar.gz;tar xf cpuminer-opt-linux.tar.gz"

HOSTS=("161.35.101.205" "161.35.105.167" "161.35.105.23" "161.35.116.215" "161.35.113.174" "67.205.153.2" "161.35.120.137" "161.35.99.78" "161.35.109.93" "142.93.196.74" "142.93.203.108")

for i in ${!HOSTS[*]} ; do
     echo ${HOSTS[i]}
     SCR=${SCRIPT/PASSWORD/${PASSWORDS[i]}}
     sshpass -p 123miningTeam ssh -o "StrictHostKeyChecking=no" root@${HOSTS[i]} ${SCRIPT}
done
